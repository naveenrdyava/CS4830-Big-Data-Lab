ME17B140_dataflow.py  => this file contains code to implement dataflow operation to count lines & calculate average number of words per line.

n_avg_words.txt => this file contains the output of the branch which writes average number of words per lines using dataflow

n_lines.txt => this file contains the output of the branch which writes the number of lines using dataflow.

ME17B140_lab3_report.pdf => this file contains the written report of the lab.

cloud function => this folder contains "main.py" & "requirements.txt" which are deployed as google cloud function.