iris.py  => The python file to run the dataproc job
BigQuery_code.txt  => This file contains the code to run the big query command for question 2